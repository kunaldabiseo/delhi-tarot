# Delhi Tarot — Sunitaa Tank (Client Preview)

Client preview of the Delhi Tarot website by Sunitaa Tank.

- **Live URL:** Served via GitHub Pages on the `main` branch.
- **Indexing:** Disabled. Every page carries `<meta name="robots" content="noindex, nofollow">` and the site ships a blocking `robots.txt`.
- **Entry point:** `index.html`.

Not for public discovery — please do not share the URL beyond the intended client.
